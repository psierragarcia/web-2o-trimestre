function MostrarVentanaEmergente() {
    // Función para crear y mostrar la ventana emergente después de 3 segundos
    setTimeout(function() {
        // Crea un elemento de imagen con la ruta de la imagen que deseas mostrar
        const imagen = new Image();
        imagen.src = "IMÁGENES/oferta1.png"; // Cambia "ruta/a/la/imagen.jpg" por la ruta real de tu imagen
        imagen.alt = "Mensaje Emergente"; // Agrega un texto alternativo para accesibilidad

        // Crea un contenedor para la imagen
        const ventanaEmergente = document.createElement("div");
        ventanaEmergente.classList.add("ventana-emergente");
        ventanaEmergente.appendChild(imagen);

        // Agrega la ventana emergente al cuerpo del documento
        document.body.appendChild(ventanaEmergente);

        // Cierra la ventana emergente después de cierto tiempo
        setTimeout(function() {
            document.body.removeChild(ventanaEmergente);
        }, 5000);
    }, 3000);
}

function cerrarVentanaEmergente() {
    // Obtiene el elemento de la ventana emergente
    var ventanaEmergente = document.getElementById('ventanaEmergente');
  
    // Oculta la ventana emergente
    ventanaEmergente.style.display = 'none';
}
