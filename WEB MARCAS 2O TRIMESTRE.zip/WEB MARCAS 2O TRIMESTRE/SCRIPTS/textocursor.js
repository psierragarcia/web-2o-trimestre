document.addEventListener('DOMContentLoaded', function() {
  // Selecciona todas las imágenes
  var imagenes = document.querySelectorAll('img');

  // Obtén el elemento del tooltip
  var tooltip = document.getElementById('tooltip');

  // Establece el texto del tooltip
  tooltip.innerText = "NexusTech";

  // Agrega evento mouseover para mostrar el tooltip cuando el cursor pasa sobre una imagen
  imagenes.forEach(function(imagen) {
      imagen.addEventListener('mouseover', function(event) {
          tooltip.style.display = 'block'; // Muestra el tooltip
          tooltip.style.left = (event.pageX + 10) + 'px'; // Ajusta la posición horizontal del tooltip
          tooltip.style.top = (event.pageY + 10) + 'px'; // Ajusta la posición vertical del tooltip
      });

      // Agrega evento mouseout para ocultar el tooltip cuando el cursor sale de la imagen
      imagen.addEventListener('mouseout', function(event) {
          tooltip.style.display = 'none'; // Oculta el tooltip
      });
  });

  // Agrega evento mousemove para actualizar la posición del tooltip mientras el cursor está sobre una imagen
  document.addEventListener('mousemove', function(event) {
      tooltip.style.left = (event.pageX + 10) + 'px'; // Ajusta la posición horizontal del tooltip
      tooltip.style.top = (event.pageY + 10) + 'px'; // Ajusta la posición vertical del tooltip
  });
});