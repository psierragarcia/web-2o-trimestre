function buscar() {
    const searchQuery = document.getElementById("searchInput").value.toLowerCase();
    const productList = ["Sobremesa", "Móviles", "Portátiles"]; // Lista de productos (puedes obtenerla de una fuente de datos)
    const results = document.getElementById("searchResults");
    let i;

    // Si la barra de búsqueda está vacía, limpiar resultados y salir de la función
    if (searchQuery.trim() === "") {
        results.innerHTML = "";
        return;
    }

    // Limpiar resultados anteriores
    results.innerHTML = "";

    // Iterar sobre los productos y mostrar los que coincidan con la búsqueda
    for (i = 0; i < productList.length; i++) {
        if (productList[i].toLowerCase().includes(searchQuery)) { // Buscar si el nombre del producto incluye la cadena de búsqueda
            const item = document.createElement("a"); // Crear un elemento <a> en lugar de <div>
            item.textContent = productList[i];
            item.href = productList[i] + ".html"; // Configurar el atributo href con la URL de la página
            const resultItem = document.createElement("div"); // Crear un contenedor para cada resultado
            resultItem.appendChild(item);
            results.appendChild(resultItem);
        }
    }
}