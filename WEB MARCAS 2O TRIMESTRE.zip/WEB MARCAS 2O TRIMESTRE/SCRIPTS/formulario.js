document.addEventListener('DOMContentLoaded', function() {
    // Selecciona el formulario
    var formulario = document.getElementById('formulario-contacto');
  
    // Agrega un evento de envío al formulario
    formulario.addEventListener('submit', function(event) {
      // Evita que el formulario se envíe
      event.preventDefault();
  
      // Muestra el mensaje de agradecimiento
      var mensajeEnviado = document.getElementById('mensaje-enviado');
      mensajeEnviado.style.display = 'block';
  
      // Limpia el contenido del formulario
      formulario.reset();
    });
  });