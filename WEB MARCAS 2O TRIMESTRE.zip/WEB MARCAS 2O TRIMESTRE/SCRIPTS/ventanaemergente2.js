// Función para mostrar una ventana emergente después de un retraso de 3 segundos (3000 milisegundos)
function mostrarVentanaEmergente2r() {
    // Se establece un temporizador para ejecutar el código después de 3 segundos
    setTimeout(function() {
        // Crear una nueva instancia de la clase Image
        const imagen = new Image();
        // Establecer la ruta de origen de la imagen
        imagen.src = "IMÁGENES/NADAL.png";

        // Crear un nuevo elemento div para la ventana emergente
        const ventanaEmergente2 = document.createElement("div");
        // Agregar una clase al elemento div para darle estilo
        ventanaEmergente2.classList.add("ventana-emergente-2");
        // Agregar la imagen al elemento div de la ventana emergente
        ventanaEmergente2.appendChild(imagen);

        // Agregar la ventana emergente al cuerpo del documento HTML
        document.body.appendChild(ventanaEmergente2);

        // Establecer un temporizador para eliminar la ventana emergente después de 5 segundos (5000 milisegundos)
        setTimeout(function() {
            // Eliminar la ventana emergente del cuerpo del documento HTML
            document.body.removeChild(ventanaEmergente2);
        }, 5000);
    }, 3000); // Fin del temporizador de 3 segundos
}

// Función para cerrar la ventana emergente manualmente
function cerrarVentanaEmergente2() {
    // Obtener el elemento de la ventana emergente por su ID
    var ventanaEmergente2 = document.getElementById('ventanaEmergente2');
    // Ocultar la ventana emergente estableciendo su estilo de visualización en 'none'
    ventanaEmergente2.style.display = 'none';
}