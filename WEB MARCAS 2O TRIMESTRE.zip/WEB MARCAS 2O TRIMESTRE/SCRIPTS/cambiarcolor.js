// Evento para abrir el selector de color al hacer clic en el botón del icono
document.getElementById("cambiarColor").addEventListener("click", function() {
    // Abre el selector de color al hacer clic en el botón
    document.getElementById("colorInputPicker").click();
});

// Evento que se dispara cuando se selecciona un color
document.getElementById("colorInputPicker").addEventListener("input", function() {
    const color = this.value; // Obtiene el valor del color seleccionado
    const body = document.body;

    // Aplica el color de fondo seleccionado al cuerpo de la página
    body.style.backgroundColor = color;

    // Aplica el color de texto seleccionado al cuerpo de la página
    body.style.color = color;
});

// Función para determinar si un color es oscuro o claro
function isDark(color) {
    // Convierte el color a su representación hexadecimal
    const hexColor = color.substring(1); // Elimina el carácter '#' al principio
    // Obtiene los componentes de color (rojo, verde, azul)
    const r = parseInt(hexColor.substring(0,2), 16); // Convierte los primeros 2 caracteres a un número decimal
    const g = parseInt(hexColor.substring(2,4), 16); // Convierte los siguientes 2 caracteres a un número decimal
    const b = parseInt(hexColor.substring(4,6), 16); // Convierte los últimos 2 caracteres a un número decimal

    // Calcula el luminance del color
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance <= 0.5; // Retorna true si el color es oscuro, false si es claro
}