// Definir una variable para mantener el índice de la imagen actual
let indiceImagenActual = 0;

// Obtener el total de imágenes disponibles en el documento HTML
const totalImagenes = document.querySelectorAll('.imagen').length;

// Llamar a la función mostrarImagen para mostrar la imagen actual
mostrarImagen(indiceImagenActual);

// Función para cambiar la imagen según la dirección proporcionada
function cambiarImagen(direccion) {
  // Incrementar o decrementar el índice de la imagen actual según la dirección
  indiceImagenActual += direccion;

  // Si el índice supera el total de imágenes, volver al principio
  if (indiceImagenActual >= totalImagenes) {
    indiceImagenActual = 0;
  } 
  // Si el índice es menor que 0, ir a la última imagen
  else if (indiceImagenActual < 0) {
    indiceImagenActual = totalImagenes - 1;
  }

  // Mostrar la imagen correspondiente al nuevo índice
  mostrarImagen(indiceImagenActual);
}

// Función para mostrar una imagen específica basada en su índice
function mostrarImagen(indice) {
  // Obtener todas las imágenes en el documento HTML
  const imagenes = document.querySelectorAll('.imagen');
  
  // Ocultar todas las imágenes estableciendo su estilo de visualización en 'none'
  imagenes.forEach((imagen) => {
    imagen.style.display = 'none';
  });
  
  // Mostrar la imagen correspondiente al índice proporcionado estableciendo su estilo de visualización en 'block'
  imagenes[indice].style.display = 'block';
}